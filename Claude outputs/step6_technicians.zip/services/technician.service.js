import "server-only";
import { prisma } from "@/lib/prisma";
import { AppError } from "@/lib/errors";
import { assertModule, hasModule } from "@/lib/modules";
import { can } from "@/lib/permissions";
import { dayEnd, dayStart, dayToDbDate, today } from "@/lib/dates";

// ============================================================
// الفنيون (وحدة technicians)
// - الفني بيتحدد على سطر الخدمة في الفاتورة (تركيب/صيانة) ومعاه الموعد والعنوان
// - المواعيد: سطور الفواتير + زيارات عقود الصيانة في شاشة واحدة
// - العمولة: نسبة الفني × صافي سطور الخدمات اللي نفذها (البيع ناقص المرتجع)
// ============================================================

const n = (v) => (v == null ? 0 : Number(v));
const round2 = (v) => Math.round((v + Number.EPSILON) * 100) / 100;
const branchScope = (user) =>
  can(user, "allBranches.view") ? {} : { branchId: user.branch.id };

const toDTO = (t) => ({ ...t, commissionRate: n(t.commissionRate) });

export async function getTechnicians({ activeOnly = false } = {}) {
  await assertModule("technicians");
  const rows = await prisma.technician.findMany({
    where: activeOnly ? { isActive: true } : {},
    orderBy: { id: "asc" },
    include: {
      _count: { select: { saleItems: true, contracts: true, visits: true } },
    },
  });
  return rows.map(toDTO);
}

// للشاشات اللي الفني فيها اختياري (العقود والمواعيد): فاضية لو الوحدة مقفولة
export async function techniciansIfEnabled() {
  if (!(await hasModule("technicians"))) return [];
  return getTechnicians({ activeOnly: true });
}

export async function createTechnician(data) {
  await assertModule("technicians");
  return prisma.technician.create({ data, select: { id: true } });
}

export async function updateTechnician({ id, ...data }) {
  await assertModule("technicians");
  await prisma.technician.update({ where: { id }, data });
  return { id };
}

// الفني اللي عليه شغل بيتوقف بس (عشان تاريخه وعمولاته)
export async function deleteTechnician(id) {
  await assertModule("technicians");
  const t = await prisma.technician.findUnique({
    where: { id },
    include: {
      _count: { select: { saleItems: true, contracts: true, visits: true } },
    },
  });
  if (!t) throw new AppError("NotFound");
  if (t._count.saleItems + t._count.contracts + t._count.visits > 0)
    throw new AppError("TechnicianInUse");
  await prisma.technician.delete({ where: { id } });
  return { id };
}

// ------------------------------------------------------------
// الفاتورة: الفني والموعد على سطور الخدمات
// items: سطور الفاتورة بعد التحقق (product فيه isService)
// بيرجع لكل سطر حقول الموعد (أو {} لو مفيش)
// ------------------------------------------------------------
export async function prepareSaleJobs(items) {
  const on = await hasModule("technicians");
  const ids = [
    ...new Set(
      items
        .map((it) => it.job?.technicianId)
        .filter((x) => Number.isInteger(x)),
    ),
  ];
  const techs =
    on && ids.length
      ? await prisma.technician.findMany({
          where: { id: { in: ids } },
          select: { id: true },
        })
      : [];
  const known = new Set(techs.map((t) => t.id));
  return items.map((it, i) => {
    const job = it.job;
    if (!on || !job || !it.product.isService) return {};
    if (job.technicianId && !known.has(job.technicianId))
      throw new AppError("TechnicianNotFound", null, {
        [`items.${i}.job`]: "TechnicianNotFound",
      });
    const at = job.at ? new Date(job.at) : null;
    if (at && Number.isNaN(at.getTime())) throw new AppError("InvalidDate");
    if (!job.technicianId && !at) return {};
    return {
      technicianId: job.technicianId ?? null,
      jobAt: at,
      jobAddress: job.address ?? null,
      jobNote: job.note ?? null,
      jobStatus: job.status === "done" ? "done" : "pending",
      jobDoneAt:
        job.status === "done"
          ? job.doneAt
            ? new Date(job.doneAt)
            : new Date()
          : null,
    };
  });
}

// ------------------------------------------------------------
// المواعيد: سطور الفواتير + زيارات العقود
// ------------------------------------------------------------
export async function listJobs(
  { from, to, technicianId, status = "pending", type = "all" },
  user,
) {
  const [techOn, contractsOn] = await Promise.all([
    hasModule("technicians"),
    hasModule("maintenanceContracts"),
  ]);
  if (!techOn && !contractsOn) throw new AppError("ModuleDisabled");
  const start = from ? dayStart(from) : undefined;
  const end = to ? dayEnd(to) : undefined;
  const rows = [];

  if (techOn && type !== "visit") {
    const items = await prisma.saleItem.findMany({
      where: {
        jobStatus: status === "all" ? { not: null } : status,
        sale: { type: "sale", ...branchScope(user) },
        ...(technicianId ? { technicianId } : {}),
        ...(start || end
          ? {
              OR: [
                {
                  jobAt: {
                    // المستني المتأخر بيظهر كمان (من غير بداية للفترة)
                    ...(start && status !== "pending" ? { gte: start } : {}),
                    ...(end ? { lte: end } : {}),
                  },
                },
                // من غير موعد
                ...(status !== "done" ? [{ jobAt: null }] : []),
              ],
            }
          : {}),
      },
      orderBy: [{ jobAt: "asc" }, { id: "asc" }],
      take: 500,
      select: {
        id: true,
        arName: true,
        enName: true,
        qty: true,
        jobAt: true,
        jobAddress: true,
        jobStatus: true,
        jobDoneAt: true,
        jobNote: true,
        technician: { select: { id: true, arName: true, enName: true } },
        sale: {
          select: {
            id: true,
            number: true,
            customerArName: true,
            customerEnName: true,
            customer: { select: { phone: true } },
          },
        },
      },
    });
    for (const it of items)
      rows.push({
        overdue:
          it.jobStatus === "pending" &&
          it.jobAt &&
          it.jobAt < dayStart(today()),
        key: `sale-${it.id}`,
        type: "sale",
        id: it.id,
        at: it.jobAt,
        title: { arName: it.arName, enName: it.enName },
        qty: n(it.qty),
        technician: it.technician,
        customer: {
          arName: it.sale.customerArName,
          enName: it.sale.customerEnName,
        },
        phone: it.sale.customer?.phone ?? null,
        address: it.jobAddress,
        status: it.jobStatus,
        doneAt: it.jobDoneAt,
        note: it.jobNote,
        ref: { kind: "sale", id: it.sale.id, number: it.sale.number },
      });
  }

  if (contractsOn && type !== "sale") {
    const visits = await prisma.maintenanceVisit.findMany({
      where: {
        ...(status === "all"
          ? {}
          : status === "pending"
            ? { status: "pending" }
            : status === "done"
              ? { status: "done" }
              : { status: "skipped" }),
        contract: { status: { not: "cancelled" }, ...branchScope(user) },
        ...(technicianId
          ? {
              OR: [
                { technicianId },
                { technicianId: null, contract: { technicianId } },
              ],
            }
          : {}),
        ...(start || end
          ? {
              dueDate: {
                // المتأخر بيظهر مع أول يوم في الفترة
                ...(start && status !== "pending"
                  ? { gte: dayToDbDate(from) }
                  : {}),
                ...(end ? { lte: dayToDbDate(to) } : {}),
              },
            }
          : {}),
      },
      orderBy: [{ dueDate: "asc" }, { id: "asc" }],
      take: 500,
      select: {
        id: true,
        dueDate: true,
        status: true,
        doneAt: true,
        note: true,
        technician: { select: { id: true, arName: true, enName: true } },
        contract: {
          select: {
            id: true,
            number: true,
            deviceName: true,
            address: true,
            technician: { select: { id: true, arName: true, enName: true } },
            customer: { select: { arName: true, enName: true, phone: true } },
          },
        },
      },
    });
    const todayDay = today();
    for (const v of visits) {
      const due = v.dueDate.toISOString().slice(0, 10);
      rows.push({
        key: `visit-${v.id}`,
        type: "visit",
        id: v.id,
        at: v.dueDate,
        dueDay: due,
        overdue: v.status === "pending" && due < todayDay,
        title: { arName: v.contract.deviceName, enName: v.contract.deviceName },
        technician: v.technician ?? v.contract.technician,
        customer: v.contract.customer,
        phone: v.contract.customer?.phone ?? null,
        address: v.contract.address,
        status: v.status === "skipped" ? "cancelled" : v.status,
        doneAt: v.doneAt,
        note: v.note,
        ref: { kind: "contract", id: v.contract.id, number: v.contract.number },
      });
    }
  }

  rows.sort(
    (a, b) =>
      (a.at ? new Date(a.at).getTime() : 0) -
      (b.at ? new Date(b.at).getTime() : 0),
  );
  return rows;
}

// تحديث موعد سطر فاتورة: اتنفذ / اتأجل لموعد تاني / اتلغى / فني تاني
export async function updateSaleJob(
  { id, status, at, technicianId, note },
  user,
) {
  await assertModule("technicians");
  const it = await prisma.saleItem.findFirst({
    where: { id, jobStatus: { not: null }, sale: branchScope(user) },
    select: { id: true },
  });
  if (!it) throw new AppError("NotFound");
  if (technicianId) {
    const t = await prisma.technician.findUnique({
      where: { id: technicianId },
      select: { id: true },
    });
    if (!t) throw new AppError("TechnicianNotFound");
  }
  await prisma.saleItem.update({
    where: { id },
    data: {
      ...(status
        ? {
            jobStatus: status,
            jobDoneAt: status === "done" ? new Date() : null,
          }
        : {}),
      ...(at !== undefined ? { jobAt: at ? new Date(at) : null } : {}),
      ...(technicianId !== undefined ? { technicianId } : {}),
      ...(note !== undefined ? { jobNote: note } : {}),
    },
  });
  return { id };
}

// ------------------------------------------------------------
// تقرير العمولات: لكل فني صافي سطور الخدمات اللي نفذها في الفترة
// (البيع ناقص المرتجع) × نسبته
// ------------------------------------------------------------
export async function commissionReport({ from, to, technicianId }, user) {
  await assertModule("technicians");
  const items = await prisma.saleItem.findMany({
    where: {
      technicianId: technicianId ?? { not: null },
      sale: {
        ...branchScope(user),
        date: {
          ...(from ? { gte: dayStart(from) } : {}),
          ...(to ? { lte: dayEnd(to) } : {}),
        },
      },
    },
    orderBy: { id: "asc" },
    select: {
      id: true,
      arName: true,
      enName: true,
      qty: true,
      netAmount: true,
      jobStatus: true,
      technicianId: true,
      sale: {
        select: {
          id: true,
          type: true,
          number: true,
          date: true,
          customerArName: true,
          customerEnName: true,
        },
      },
    },
  });
  const techs = await prisma.technician.findMany({
    where: { id: { in: [...new Set(items.map((i) => i.technicianId))] } },
    select: { id: true, arName: true, enName: true, commissionRate: true },
  });
  const byId = new Map(
    techs.map((t) => [
      t.id,
      { ...toDTO(t), lines: [], jobs: 0, net: 0, commission: 0 },
    ]),
  );
  for (const it of items) {
    const t = byId.get(it.technicianId);
    if (!t) continue;
    const sign = it.sale.type === "return" ? -1 : 1;
    const net = sign * n(it.netAmount);
    t.net = round2(t.net + net);
    if (sign > 0) t.jobs++;
    t.lines.push({
      id: it.id,
      name: { arName: it.arName, enName: it.enName },
      qty: sign * n(it.qty),
      net,
      status: it.jobStatus,
      sale: it.sale,
    });
  }
  const rows = [...byId.values()].map((t) => ({
    ...t,
    commission: round2((t.net * t.commissionRate) / 100),
  }));
  return {
    rows,
    totals: {
      jobs: rows.reduce((s, r) => s + r.jobs, 0),
      net: round2(rows.reduce((s, r) => s + r.net, 0)),
      commission: round2(rows.reduce((s, r) => s + r.commission, 0)),
    },
  };
}
