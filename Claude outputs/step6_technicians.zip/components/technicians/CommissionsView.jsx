"use client";

import { useCallback, useEffect, useState } from "react";
import { Card, Col, Row, Select, Table, Tag } from "antd";
import { useLocale, useTranslations } from "next-intl";
import PageHeader from "@/components/common/PageHeader";
import DayPicker from "@/components/common/DayPicker";
import ExportButtons from "@/components/reports/ExportButtons";
import { showActionError } from "@/components/common/actionError";
import { useCurrency } from "@/components/common/CurrencyProvider";
import { Link } from "@/i18n/routing";
import { formatDate, today } from "@/lib/dates";
import { saleDocNo } from "@/lib/doc-number";
import { commissionReportAction } from "@/actions/technician.actions";

// ============================================================
// عمولات الفنيين: صافي الخدمات اللي نفذها كل فني في الفترة
// (البيع ناقص المرتجع) × نسبته = المستحق له
// ============================================================
export default function CommissionsView({ technicians = [] }) {
  const t = useTranslations("Technicians");
  const tAlerts = useTranslations("Alerts");
  const locale = useLocale();
  const { amount: money } = useCurrency();
  const nm = (x) => (x ? (locale === "ar" ? x.arName : x.enName) : "");
  const now = today();
  const [filters, setFilters] = useState({
    from: `${now.slice(0, 7)}-01`,
    to: now,
    technicianId: undefined,
  });
  const [result, setResult] = useState({ key: null, data: null });
  const key = JSON.stringify(filters);
  const load = useCallback(() => commissionReportAction(filters), [filters]);

  useEffect(() => {
    let alive = true;
    load().then((res) => {
      if (!alive) return;
      if (!res.success) showActionError(res, tAlerts, locale);
      setResult((prev) => ({ key, data: res.success ? res.data : prev.data }));
    });
    return () => {
      alive = false;
    };
  }, [load, key, tAlerts, locale]);

  const set = (patch) => setFilters((f) => ({ ...f, ...patch }));
  const data = result.data ?? { rows: [], totals: {} };

  const build = () => ({
    title: t("CommissionsTitle"),
    fileName: "technician-commissions",
    info: [[t("Period"), `${filters.from ?? ""} — ${filters.to ?? ""}`]],
    columns: [
      { title: t("Technician"), key: "name" },
      { title: t("JobsCount"), key: "jobs", type: "number" },
      { title: t("ServicesNet"), key: "net", type: "money" },
      { title: t("Rate"), key: "rate" },
      { title: t("Commission"), key: "commission", type: "money" },
    ],
    rows: data.rows.map((r) => ({
      key: r.id,
      name: nm(r),
      jobs: r.jobs,
      net: r.net,
      rate: `${r.commissionRate}%`,
      commission: r.commission,
    })),
    totals: {
      jobs: data.totals.jobs,
      net: data.totals.net,
      commission: data.totals.commission,
    },
  });

  return (
    <>
      <PageHeader
        title={t("CommissionsTitle")}
        subtitle={t("CommissionsSubtitle")}
        extra={<ExportButtons disabled={!data.rows.length} build={build} />}
      />
      <Card size="small" className="mb-3">
        <Row gutter={[12, 12]}>
          <Col xs={12} md={5}>
            <DayPicker
              value={filters.from}
              onChange={(v) => set({ from: v })}
            />
          </Col>
          <Col xs={12} md={5}>
            <DayPicker value={filters.to} onChange={(v) => set({ to: v })} />
          </Col>
          <Col xs={24} md={6}>
            <Select
              allowClear
              showSearch
              style={{ width: "100%" }}
              placeholder={t("AllTechnicians")}
              optionFilterProp="label"
              value={filters.technicianId}
              onChange={(v) => set({ technicianId: v ?? undefined })}
              options={technicians.map((x) => ({ value: x.id, label: nm(x) }))}
            />
          </Col>
        </Row>
      </Card>

      <Table
        size="small"
        rowKey="id"
        loading={result.key !== key}
        dataSource={data.rows}
        pagination={false}
        scroll={{ x: 700 }}
        expandable={{
          expandedRowRender: (r) => (
            <Table
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={r.lines}
              columns={[
                {
                  title: t("Invoice"),
                  width: 110,
                  render: (_, l) => (
                    <Link
                      href={`/invoices/${l.sale.type === "return" ? "sales-returns" : "sales"}/${l.sale.id}`}
                    >
                      <bdi>{saleDocNo(l.sale.type, l.sale.number)}</bdi>
                    </Link>
                  ),
                },
                {
                  title: t("Date"),
                  width: 100,
                  render: (_, l) => <bdi>{formatDate(l.sale.date)}</bdi>,
                },
                { title: t("Job"), render: (_, l) => nm(l.name) },
                {
                  title: t("Customer"),
                  render: (_, l) =>
                    nm({
                      arName: l.sale.customerArName,
                      enName: l.sale.customerEnName,
                    }) || "—",
                },
                {
                  title: t("Status"),
                  width: 100,
                  render: (_, l) =>
                    l.status ? <Tag>{t(`JobStatus_${l.status}`)}</Tag> : "—",
                },
                {
                  title: t("ServicesNet"),
                  width: 120,
                  align: "end",
                  render: (_, l) => (
                    <span style={{ color: l.net < 0 ? "#cf1322" : undefined }}>
                      {money(l.net)}
                    </span>
                  ),
                },
              ]}
            />
          ),
        }}
        columns={[
          { title: t("Technician"), render: (_, r) => <b>{nm(r)}</b> },
          { title: t("JobsCount"), width: 110, dataIndex: "jobs" },
          {
            title: t("ServicesNet"),
            width: 140,
            align: "end",
            render: (_, r) => money(r.net),
          },
          {
            title: t("Rate"),
            width: 90,
            render: (_, r) => <Tag color="purple">{r.commissionRate}%</Tag>,
          },
          {
            title: t("Commission"),
            width: 140,
            align: "end",
            render: (_, r) => <b>{money(r.commission)}</b>,
          },
        ]}
        summary={() =>
          data.rows.length ? (
            <Table.Summary.Row>
              <Table.Summary.Cell index={0} colSpan={2}>
                <b>{t("Total")}</b>
              </Table.Summary.Cell>
              <Table.Summary.Cell index={2}>
                {data.totals.jobs}
              </Table.Summary.Cell>
              <Table.Summary.Cell index={3} align="end">
                {money(data.totals.net)}
              </Table.Summary.Cell>
              <Table.Summary.Cell index={4} />
              <Table.Summary.Cell index={5} align="end">
                <b>{money(data.totals.commission)}</b>
              </Table.Summary.Cell>
            </Table.Summary.Row>
          ) : null
        }
      />
    </>
  );
}
