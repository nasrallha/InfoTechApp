"use client";

import { useState } from "react";
import {
  Button,
  Form,
  Input,
  InputNumber,
  Modal,
  Popconfirm,
  Space,
  Switch,
  Table,
  Tag,
} from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useLocale, useTranslations } from "next-intl";
import PageHeader from "@/components/common/PageHeader";
import { message } from "@/components/common/feedback";
import { showActionError } from "@/components/common/actionError";
import { applyFieldErrors } from "@/lib/form-errors";
import { useCan } from "@/components/auth/AuthProvider";
import {
  createTechnicianAction,
  deleteTechnicianAction,
  updateTechnicianAction,
} from "@/actions/technician.actions";

// ============================================================
// الفنيون: الاسم والجوال ونسبة العمولة من الخدمات اللي بينفذها
// ============================================================
export default function TechniciansView({ technicians }) {
  const t = useTranslations("Technicians");
  const tAlerts = useTranslations("Alerts");
  const locale = useLocale();
  const can = useCan();
  const [form] = Form.useForm();
  const [editing, setEditing] = useState(null); // {} جديد | فني
  const [saving, setSaving] = useState(false);
  const nm = (x) => (locale === "ar" ? x.arName : x.enName);
  const req = [
    { required: true, whitespace: true, message: tAlerts("RequiredField") },
  ];

  const save = async (v) => {
    setSaving(true);
    const res = editing?.id
      ? await updateTechnicianAction({ ...v, id: editing.id })
      : await createTechnicianAction(v);
    setSaving(false);
    if (!res.success) {
      applyFieldErrors(form, res.fieldErrors, tAlerts);
      return showActionError(res, tAlerts, locale);
    }
    message.success(t("Saved"));
    setEditing(null);
  };

  const remove = async (r) => {
    const res = await deleteTechnicianAction(r.id);
    if (!res.success) return showActionError(res, tAlerts, locale);
    message.success(t("Deleted"));
  };

  return (
    <>
      <PageHeader
        title={t("Title")}
        subtitle={t("Subtitle")}
        buttonTitle={can("technicians.create") ? t("New") : null}
        onButtonClick={() => setEditing({})}
      />
      <Table
        rowKey="id"
        size="small"
        dataSource={technicians}
        pagination={false}
        scroll={{ x: 640 }}
        columns={[
          { title: "#", width: 60, render: (_, __, i) => i + 1 },
          { title: t("Name"), render: (_, r) => <b>{nm(r)}</b> },
          {
            title: t("Phone"),
            width: 150,
            render: (_, r) => (r.phone ? <bdi>{r.phone}</bdi> : "—"),
          },
          {
            title: t("Rate"),
            width: 110,
            render: (_, r) => <Tag color="purple">{r.commissionRate}%</Tag>,
          },
          {
            title: t("Jobs"),
            width: 100,
            render: (_, r) => r._count.saleItems + r._count.visits,
          },
          {
            title: t("Status"),
            width: 100,
            render: (_, r) =>
              r.isActive ? (
                <Tag color="green">{t("Active")}</Tag>
              ) : (
                <Tag>{t("Inactive")}</Tag>
              ),
          },
          {
            title: "",
            width: 100,
            render: (_, r) => (
              <Space>
                {can("technicians.update") && (
                  <Button
                    type="text"
                    icon={<EditOutlined />}
                    onClick={() => setEditing(r)}
                  />
                )}
                {can("technicians.delete") && (
                  <Popconfirm
                    title={t("ConfirmDelete")}
                    onConfirm={() => remove(r)}
                  >
                    <Button danger type="text" icon={<DeleteOutlined />} />
                  </Popconfirm>
                )}
              </Space>
            ),
          },
        ]}
      />

      {editing && (
        <Modal
          open
          title={editing.id ? t("Edit") : t("New")}
          onCancel={() => setEditing(null)}
          onOk={() => form.submit()}
          confirmLoading={saving}
          destroyOnHidden
        >
          <Form
            form={form}
            layout="vertical"
            onFinish={save}
            initialValues={{
              arName: editing.arName ?? "",
              enName: editing.enName ?? "",
              phone: editing.phone ?? "",
              commissionRate: editing.commissionRate ?? 0,
              isActive: editing.isActive ?? true,
              notes: editing.notes ?? "",
            }}
          >
            <Form.Item name="arName" label={t("ArName")} rules={req}>
              <Input />
            </Form.Item>
            <Form.Item name="enName" label={t("EnName")} rules={req}>
              <Input dir="ltr" />
            </Form.Item>
            <Form.Item name="phone" label={t("Phone")}>
              <Input dir="ltr" />
            </Form.Item>
            <Form.Item
              name="commissionRate"
              label={t("Rate")}
              extra={t("RateHint")}
            >
              <InputNumber
                min={0}
                max={100}
                suffix="%"
                style={{ width: 160 }}
              />
            </Form.Item>
            <Form.Item name="notes" label={t("Notes")}>
              <Input.TextArea rows={2} maxLength={500} />
            </Form.Item>
            <Form.Item
              name="isActive"
              label={t("Status")}
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>
          </Form>
        </Modal>
      )}
    </>
  );
}
