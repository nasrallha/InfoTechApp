"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Button,
  Card,
  Col,
  DatePicker,
  Modal,
  Popconfirm,
  Row,
  Segmented,
  Select,
  Space,
  Table,
  Tag,
} from "antd";
import {
  CheckOutlined,
  ClockCircleOutlined,
  CloseOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import { useLocale, useTranslations } from "next-intl";
import PageHeader from "@/components/common/PageHeader";
import DayPicker from "@/components/common/DayPicker";
import { message } from "@/components/common/feedback";
import { showActionError } from "@/components/common/actionError";
import { useCan, useModule } from "@/components/auth/AuthProvider";
import { Link } from "@/i18n/routing";
import { formatDate, formatDateTime, today } from "@/lib/dates";
import { formatDocNo, saleDocNo } from "@/lib/doc-number";
import {
  listJobsAction,
  updateSaleJobAction,
  updateVisitAction,
} from "@/actions/technician.actions";

const plusDays = (n) => dayjs().add(n, "day").format("YYYY-MM-DD");
const STATUS_COLORS = {
  pending: "blue",
  done: "green",
  cancelled: "default",
};

// ============================================================
// المواعيد: تركيبات وخدمات الفواتير + زيارات عقود الصيانة
// (متأخر بالأحمر)، وتحديث الحالة: اتنفذ / تأجيل / إلغاء
// ============================================================
export default function JobsView({ technicians = [] }) {
  const t = useTranslations("Technicians");
  const tAlerts = useTranslations("Alerts");
  const locale = useLocale();
  const can = useCan();
  const techOn = useModule("technicians");
  const contractsOn = useModule("maintenanceContracts");
  const nm = (x) => (x ? (locale === "ar" ? x.arName : x.enName) : "");
  const [filters, setFilters] = useState({
    from: today(),
    to: plusDays(7),
    technicianId: undefined,
    status: "pending",
    type: "all",
  });
  const [tick, setTick] = useState(0);
  const [result, setResult] = useState({ key: null, rows: [] });
  const [postpone, setPostpone] = useState(null);
  const key = JSON.stringify({ ...filters, tick });

  const load = useCallback(() => listJobsAction(filters), [filters]);
  useEffect(() => {
    let alive = true;
    load().then((res) => {
      if (!alive) return;
      if (!res.success) showActionError(res, tAlerts, locale);
      setResult((prev) => ({ key, rows: res.success ? res.data : prev.rows }));
    });
    return () => {
      alive = false;
    };
  }, [load, key, tAlerts, locale]);

  const set = (patch) => setFilters((f) => ({ ...f, ...patch }));
  const canRow = (r) =>
    r.type === "sale"
      ? can("technicians.jobs")
      : can("maintenanceContracts.visits");

  const update = async (r, patch) => {
    const res =
      r.type === "sale"
        ? await updateSaleJobAction({ id: r.id, ...patch })
        : await updateVisitAction({
            id: r.id,
            ...(patch.status
              ? {
                  status:
                    patch.status === "cancelled" ? "skipped" : patch.status,
                }
              : {}),
            ...(patch.at
              ? { dueDate: dayjs(patch.at).format("YYYY-MM-DD") }
              : {}),
          });
    if (!res.success) return showActionError(res, tAlerts, locale);
    message.success(t("JobUpdated"));
    setPostpone(null);
    setTick((x) => x + 1);
  };

  return (
    <>
      <PageHeader title={t("JobsTitle")} subtitle={t("JobsSubtitle")} />
      <Card size="small" className="mb-3">
        <Row gutter={[12, 12]} align="middle">
          <Col xs={12} md={4}>
            <DayPicker
              value={filters.from}
              onChange={(v) => set({ from: v })}
              allowClear
            />
          </Col>
          <Col xs={12} md={4}>
            <DayPicker
              value={filters.to}
              onChange={(v) => set({ to: v })}
              allowClear
            />
          </Col>
          <Col xs={24} md={5}>
            <Select
              allowClear
              showSearch
              style={{ width: "100%" }}
              placeholder={t("AllTechnicians")}
              optionFilterProp="label"
              value={filters.technicianId}
              onChange={(v) => set({ technicianId: v ?? undefined })}
              options={technicians.map((x) => ({ value: x.id, label: nm(x) }))}
            />
          </Col>
          <Col xs={24} md={6}>
            <Segmented
              block
              value={filters.status}
              onChange={(v) => set({ status: v })}
              options={["pending", "done", "cancelled", "all"].map((s) => ({
                value: s,
                label: t(`JobFilter_${s}`),
              }))}
            />
          </Col>
          {techOn && contractsOn && (
            <Col xs={24} md={5}>
              <Segmented
                block
                value={filters.type}
                onChange={(v) => set({ type: v })}
                options={["all", "sale", "visit"].map((s) => ({
                  value: s,
                  label: t(`JobType_${s}`),
                }))}
              />
            </Col>
          )}
        </Row>
      </Card>

      <Table
        size="small"
        rowKey="key"
        loading={result.key !== key}
        dataSource={result.rows}
        pagination={{ pageSize: 50, hideOnSinglePage: true }}
        scroll={{ x: 1150 }}
        columns={[
          {
            title: t("When"),
            width: 150,
            render: (_, r) => (
              <span style={{ color: r.overdue ? "#cf1322" : undefined }}>
                {r.overdue && <ClockCircleOutlined />}{" "}
                <bdi>
                  {!r.at
                    ? t("NoDate")
                    : r.type === "visit"
                      ? formatDate(r.at)
                      : formatDateTime(r.at)}
                </bdi>
                {r.overdue && (
                  <div style={{ fontSize: 12 }}>{t("Overdue")}</div>
                )}
              </span>
            ),
          },
          {
            title: t("Type"),
            width: 110,
            render: (_, r) => (
              <Tag color={r.type === "sale" ? "purple" : "cyan"}>
                {t(`JobType_${r.type}`)}
              </Tag>
            ),
          },
          {
            title: t("Job"),
            width: 200,
            render: (_, r) => (
              <span>
                <b>{nm(r.title)}</b>
                {r.note && (
                  <div style={{ color: "#888", fontSize: 12 }}>{r.note}</div>
                )}
              </span>
            ),
          },
          {
            title: t("Customer"),
            width: 190,
            render: (_, r) => (
              <span>
                {nm(r.customer) || "—"}
                {r.phone && (
                  <div style={{ color: "#888", fontSize: 12 }}>
                    <bdi>{r.phone}</bdi>
                  </div>
                )}
              </span>
            ),
          },
          {
            title: t("Address"),
            width: 180,
            render: (_, r) => r.address || "—",
          },
          {
            title: t("Technician"),
            width: 130,
            render: (_, r) => nm(r.technician) || "—",
          },
          {
            title: t("Ref"),
            width: 90,
            render: (_, r) =>
              r.ref.kind === "sale" ? (
                <Link href={`/invoices/sales/${r.ref.id}`}>
                  <bdi>{saleDocNo("sale", r.ref.number)}</bdi>
                </Link>
              ) : (
                <Link href={`/maintenance-contracts/${r.ref.id}`}>
                  <bdi>{formatDocNo("contract", r.ref.number)}</bdi>
                </Link>
              ),
          },
          {
            title: t("Status"),
            width: 100,
            render: (_, r) => (
              <Tag color={STATUS_COLORS[r.status]}>
                {t(`JobStatus_${r.status}`)}
              </Tag>
            ),
          },
          {
            title: "",
            width: 120,
            render: (_, r) =>
              canRow(r) && r.status === "pending" ? (
                <Space size={4}>
                  <Popconfirm
                    title={t("ConfirmDone")}
                    onConfirm={() => update(r, { status: "done" })}
                  >
                    <Button
                      size="small"
                      type="primary"
                      icon={<CheckOutlined />}
                      title={t("MarkDone")}
                    />
                  </Popconfirm>
                  <Button
                    size="small"
                    icon={<ClockCircleOutlined />}
                    title={t("Postpone")}
                    onClick={() => setPostpone(r)}
                  />
                  <Popconfirm
                    title={t("ConfirmCancel")}
                    onConfirm={() => update(r, { status: "cancelled" })}
                  >
                    <Button
                      size="small"
                      danger
                      icon={<CloseOutlined />}
                      title={t("CancelJob")}
                    />
                  </Popconfirm>
                </Space>
              ) : null,
          },
        ]}
      />

      {postpone && (
        <PostponeModal
          row={postpone}
          onClose={() => setPostpone(null)}
          onSave={(at) => update(postpone, { at })}
        />
      )}
    </>
  );
}

function PostponeModal({ row, onClose, onSave }) {
  const t = useTranslations("Technicians");
  const visit = row.type === "visit";
  const [value, setValue] = useState(row.at ? dayjs(row.at) : dayjs());
  return (
    <Modal
      open
      title={t("Postpone")}
      onCancel={onClose}
      onOk={() => value && onSave(value.toISOString())}
      destroyOnHidden
    >
      <DatePicker
        style={{ width: "100%" }}
        value={value}
        onChange={setValue}
        showTime={visit ? false : { format: "HH:mm" }}
        format={visit ? "DD/MM/YYYY" : "DD/MM/YYYY HH:mm"}
      />
    </Modal>
  );
}
