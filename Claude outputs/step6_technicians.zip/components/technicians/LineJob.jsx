"use client";

import { useEffect, useState } from "react";
import { DatePicker, Form, Input, Modal, Select, Tag } from "antd";
import { ToolOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useLocale, useTranslations } from "next-intl";
import { useModule } from "@/components/auth/AuthProvider";
import { formatDateTime } from "@/lib/dates";
import { activeTechniciansAction } from "@/actions/technician.actions";

// الفنيين النشطين (مرة واحدة لكل الصفحة)
let cache = null;
async function loadTechnicians() {
  if (!cache)
    cache = activeTechniciansAction().then((r) => (r.success ? r.data : []));
  return cache;
}

// ============================================================
// الفني والموعد لسطر خدمة في الفاتورة (وحدة technicians)
// line.job: { technicianId, at, address, note, status }
// onChange({ job })
// ============================================================
export default function LineJob({ line, onChange, disabled = false }) {
  const t = useTranslations("Technicians");
  const on = useModule("technicians");
  const locale = useLocale();
  const [open, setOpen] = useState(false);
  const [techs, setTechs] = useState([]);
  const nm = (x) => (x ? (locale === "ar" ? x.arName : x.enName) : "");

  useEffect(() => {
    if (!on || !line.isService) return;
    let alive = true;
    loadTechnicians().then((list) => alive && setTechs(list));
    return () => {
      alive = false;
    };
  }, [on, line.isService]);

  if (!on || !line.isService) return null;
  const job = line.job;
  const tech = techs.find((x) => x.id === job?.technicianId);

  return (
    <div className="mt-1">
      <Tag
        color={job?.technicianId || job?.at ? "purple" : "default"}
        icon={<ToolOutlined />}
        style={{ cursor: disabled ? "default" : "pointer" }}
        onClick={disabled ? undefined : () => setOpen(true)}
      >
        {job?.technicianId || job?.at
          ? [nm(tech), job?.at ? formatDateTime(job.at) : null]
              .filter(Boolean)
              .join(" — ")
          : t("SetJob")}
        {job?.status === "done" ? ` ✓` : ""}
      </Tag>
      {open && (
        <JobModal
          job={job}
          techs={techs}
          onClose={() => setOpen(false)}
          onSave={(v) => {
            onChange?.({ job: v });
            setOpen(false);
          }}
        />
      )}
    </div>
  );
}

function JobModal({ job, techs, onClose, onSave }) {
  const t = useTranslations("Technicians");
  const locale = useLocale();
  const [form] = Form.useForm();
  const nm = (x) => (locale === "ar" ? x.arName : x.enName);

  return (
    <Modal
      open
      title={t("JobTitle")}
      onCancel={onClose}
      onOk={() => form.submit()}
      destroyOnHidden
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          technicianId: job?.technicianId ?? undefined,
          at: job?.at ? dayjs(job.at) : undefined,
          address: job?.address ?? "",
          note: job?.note ?? "",
        }}
        onFinish={(v) =>
          onSave({
            technicianId: v.technicianId ?? null,
            at: v.at ? v.at.toISOString() : null,
            address: v.address?.trim() || null,
            note: v.note?.trim() || null,
            status: job?.status ?? "pending",
            doneAt: job?.doneAt ?? null,
          })
        }
      >
        <Form.Item name="technicianId" label={t("Technician")}>
          <Select
            allowClear
            showSearch
            optionFilterProp="label"
            options={techs.map((x) => ({ value: x.id, label: nm(x) }))}
          />
        </Form.Item>
        <Form.Item name="at" label={t("JobAt")}>
          <DatePicker
            showTime={{ format: "HH:mm" }}
            format="DD/MM/YYYY HH:mm"
            style={{ width: "100%" }}
          />
        </Form.Item>
        <Form.Item name="address" label={t("Address")}>
          <Input.TextArea rows={2} maxLength={500} />
        </Form.Item>
        <Form.Item name="note" label={t("Note")}>
          <Input maxLength={500} />
        </Form.Item>
      </Form>
    </Modal>
  );
}
