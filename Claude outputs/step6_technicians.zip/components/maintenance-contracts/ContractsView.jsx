"use client";

import { useCallback, useEffect, useState } from "react";
import { Card, Input, Segmented, Space, Table, Tag } from "antd";
import { ClockCircleOutlined } from "@ant-design/icons";
import { useLocale, useTranslations } from "next-intl";
import PageHeader from "@/components/common/PageHeader";
import { showActionError } from "@/components/common/actionError";
import { useCan } from "@/components/auth/AuthProvider";
import { useCurrency } from "@/components/common/CurrencyProvider";
import { Link, useRouter } from "@/i18n/routing";
import { formatDocNo } from "@/lib/doc-number";
import { today } from "@/lib/dates";
import { listContractsAction } from "@/actions/technician.actions";
import ContractFormModal from "./ContractFormModal";

export const CONTRACT_COLORS = {
  active: "green",
  ended: "default",
  cancelled: "red",
};

// ============================================================
// عقود الصيانة الدورية: القايمة + عقد جديد
// ============================================================
export default function ContractsView({ customers = [], technicians = [] }) {
  const t = useTranslations("Contracts");
  const tAlerts = useTranslations("Alerts");
  const locale = useLocale();
  const router = useRouter();
  const can = useCan();
  const { amount: money } = useCurrency();
  const nm = (x) => (x ? (locale === "ar" ? x.arName : x.enName) : "");
  const [status, setStatus] = useState("active");
  const [q, setQ] = useState("");
  const [text, setText] = useState("");
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState({ key: null, rows: [] });
  const key = JSON.stringify({ status, q });
  const load = useCallback(
    () => listContractsAction({ status, q }),
    [status, q],
  );
  const todayDay = today();

  useEffect(() => {
    let alive = true;
    load().then((res) => {
      if (!alive) return;
      if (!res.success) showActionError(res, tAlerts, locale);
      setResult((prev) => ({ key, rows: res.success ? res.data : prev.rows }));
    });
    return () => {
      alive = false;
    };
  }, [load, key, tAlerts, locale]);

  return (
    <>
      <PageHeader
        title={t("Title")}
        subtitle={t("Subtitle")}
        buttonTitle={can("maintenanceContracts.create") ? t("New") : null}
        onButtonClick={() => setCreating(true)}
      />
      <Card size="small" className="mb-3">
        <Space wrap>
          <Segmented
            value={status}
            onChange={setStatus}
            options={["active", "ended", "cancelled", "all"].map((s) => ({
              value: s,
              label: t(`Filter_${s}`),
            }))}
          />
          <Input.Search
            allowClear
            style={{ width: 320 }}
            placeholder={t("SearchPlaceholder")}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onSearch={(v) => setQ(v.trim())}
          />
        </Space>
      </Card>

      <Table
        size="small"
        rowKey="id"
        loading={result.key !== key}
        dataSource={result.rows}
        scroll={{ x: 1000 }}
        pagination={{ pageSize: 50, hideOnSinglePage: true }}
        onRow={(r) => ({
          onClick: () => router.push(`/maintenance-contracts/${r.id}`),
          style: { cursor: "pointer" },
        })}
        columns={[
          {
            title: t("Number"),
            width: 90,
            render: (_, r) => (
              <Link href={`/maintenance-contracts/${r.id}`}>
                <bdi>{formatDocNo("contract", r.number)}</bdi>
              </Link>
            ),
          },
          {
            title: t("Customer"),
            width: 190,
            render: (_, r) => (
              <span>
                {nm(r.customer)}
                {r.customer?.phone && (
                  <div style={{ color: "#888", fontSize: 12 }}>
                    <bdi>{r.customer.phone}</bdi>
                  </div>
                )}
              </span>
            ),
          },
          {
            title: t("Device"),
            width: 200,
            render: (_, r) => (
              <span>
                {r.deviceName}
                {r.serialText && (
                  <div style={{ color: "#888", fontSize: 12 }}>
                    <bdi>{r.serialText}</bdi>
                  </div>
                )}
              </span>
            ),
          },
          {
            title: t("Every"),
            width: 110,
            render: (_, r) => t("EveryN", { n: r.intervalMonths }),
          },
          {
            title: t("Period"),
            width: 190,
            render: (_, r) => (
              <bdi>
                {r.startDate} — {r.endDate}
              </bdi>
            ),
          },
          {
            title: t("NextVisit"),
            width: 130,
            render: (_, r) =>
              r.nextVisit ? (
                <span
                  style={{
                    color: r.nextVisit < todayDay ? "#cf1322" : undefined,
                  }}
                >
                  {r.nextVisit < todayDay && <ClockCircleOutlined />}{" "}
                  <bdi>{r.nextVisit}</bdi>
                </span>
              ) : (
                "—"
              ),
          },
          {
            title: t("Technician"),
            width: 120,
            render: (_, r) => nm(r.technician) || "—",
          },
          {
            title: t("Amount"),
            width: 110,
            align: "end",
            render: (_, r) => (r.amount != null ? money(r.amount) : "—"),
          },
          {
            title: t("Status"),
            width: 90,
            render: (_, r) => (
              <Tag color={CONTRACT_COLORS[r.status]}>
                {t(`Status_${r.status}`)}
              </Tag>
            ),
          },
        ]}
      />

      {creating && (
        <ContractFormModal
          customers={customers}
          technicians={technicians}
          onClose={() => setCreating(false)}
          onSaved={(id) => router.push(`/maintenance-contracts/${id}`)}
        />
      )}
    </>
  );
}
