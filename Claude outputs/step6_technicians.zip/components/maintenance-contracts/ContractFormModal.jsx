"use client";

import { useState } from "react";
import { Alert, Col, Form, Input, InputNumber, Modal, Row, Select } from "antd";
import { useLocale, useTranslations } from "next-intl";
import DayPicker from "@/components/common/DayPicker";
import { message } from "@/components/common/feedback";
import { showActionError } from "@/components/common/actionError";
import { applyFieldErrors } from "@/lib/form-errors";
import { today } from "@/lib/dates";
import {
  createContractAction,
  updateContractAction,
} from "@/actions/technician.actions";

// مواعيد الزيارات (نفس حساب السيرفر) عشان تبان قبل الحفظ
function schedule(start, end, every) {
  if (!start || !end || !(every > 0)) return [];
  const out = [];
  const [y, m, d] = start.split("-").map(Number);
  for (let i = 1; i <= 240; i++) {
    const tgt = new Date(Date.UTC(y, m - 1 + every * i, 1));
    const last = new Date(
      Date.UTC(tgt.getUTCFullYear(), tgt.getUTCMonth() + 1, 0),
    ).getUTCDate();
    tgt.setUTCDate(Math.min(d, last));
    const day = tgt.toISOString().slice(0, 10);
    if (day > end) break;
    out.push(day);
  }
  return out;
}

// ============================================================
// عقد صيانة جديد / تعديل بياناته
// (المدة والفترة بيتحددوا مرة واحدة مع العقد عشان جدول الزيارات)
// ============================================================
export default function ContractFormModal({
  contract = null,
  customers = [],
  technicians = [],
  onClose,
  onSaved,
}) {
  const t = useTranslations("Contracts");
  const tAlerts = useTranslations("Alerts");
  const locale = useLocale();
  const nm = (x) => (locale === "ar" ? x.arName : x.enName);
  const [form] = Form.useForm();
  const [saving, setSaving] = useState(false);
  const isEdit = Boolean(contract);
  const req = [{ required: true, message: tAlerts("RequiredField") }];
  const v = Form.useWatch([], form) ?? {};
  const visits = isEdit
    ? []
    : schedule(v.startDate, v.endDate, Number(v.intervalMonths));

  const save = async (values) => {
    setSaving(true);
    const res = isEdit
      ? await updateContractAction({ ...values, id: contract.id })
      : await createContractAction(values);
    setSaving(false);
    if (!res.success) {
      applyFieldErrors(form, res.fieldErrors, tAlerts);
      return showActionError(res, tAlerts, locale);
    }
    message.success(t(isEdit ? "Updated" : "Created"));
    onSaved?.(res.data.id);
    onClose();
  };

  const plusYear = () => {
    const d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().slice(0, 10);
  };

  return (
    <Modal
      open
      width={720}
      title={isEdit ? t("Edit") : t("New")}
      onCancel={onClose}
      onOk={() => form.submit()}
      confirmLoading={saving}
      destroyOnHidden
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={save}
        initialValues={
          isEdit
            ? {
                deviceName: contract.deviceName,
                serialText: contract.serialText ?? "",
                address: contract.address ?? "",
                amount: contract.amount ?? undefined,
                technicianId: contract.technician?.id ?? undefined,
                notes: contract.notes ?? "",
              }
            : {
                startDate: today(),
                endDate: plusYear(),
                intervalMonths: 3,
              }
        }
      >
        {!isEdit && (
          <Form.Item name="customerId" label={t("Customer")} rules={req}>
            <Select
              showSearch
              optionFilterProp="label"
              options={customers.map((c) => ({
                value: c.id,
                label: `${c.code} - ${nm(c)}${c.phone ? ` (${c.phone})` : ""}`,
              }))}
            />
          </Form.Item>
        )}
        <Row gutter={12}>
          <Col xs={24} md={14}>
            <Form.Item name="deviceName" label={t("Device")} rules={req}>
              <Input placeholder={t("DevicePlaceholder")} />
            </Form.Item>
          </Col>
          <Col xs={24} md={10}>
            <Form.Item name="serialText" label={t("Serial")}>
              <Input />
            </Form.Item>
          </Col>
        </Row>
        <Form.Item name="address" label={t("Address")}>
          <Input.TextArea rows={2} maxLength={500} />
        </Form.Item>
        {!isEdit && (
          <Row gutter={12}>
            <Col xs={8}>
              <Form.Item name="intervalMonths" label={t("Every")} rules={req}>
                <InputNumber
                  min={1}
                  max={60}
                  precision={0}
                  suffix={t("Months")}
                  style={{ width: "100%" }}
                />
              </Form.Item>
            </Col>
            <Col xs={8}>
              <Form.Item name="startDate" label={t("StartDate")} rules={req}>
                <DayPicker />
              </Form.Item>
            </Col>
            <Col xs={8}>
              <Form.Item name="endDate" label={t("EndDate")} rules={req}>
                <DayPicker />
              </Form.Item>
            </Col>
          </Row>
        )}
        {!isEdit && (
          <Alert
            type={visits.length ? "info" : "warning"}
            showIcon
            className="mb-3"
            title={
              visits.length
                ? t("VisitsPreview", {
                    n: visits.length,
                    list: visits.slice(0, 6).join("، "),
                  })
                : t("NoVisitsPreview")
            }
          />
        )}
        <Row gutter={12}>
          <Col xs={24} md={12}>
            <Form.Item name="technicianId" label={t("Technician")}>
              <Select
                allowClear
                showSearch
                optionFilterProp="label"
                options={technicians.map((x) => ({
                  value: x.id,
                  label: nm(x),
                }))}
              />
            </Form.Item>
          </Col>
          <Col xs={24} md={12}>
            <Form.Item
              name="amount"
              label={t("Amount")}
              tooltip={t("AmountHint")}
            >
              <InputNumber min={0} style={{ width: "100%" }} />
            </Form.Item>
          </Col>
        </Row>
        <Form.Item name="notes" label={t("Notes")}>
          <Input.TextArea rows={2} maxLength={1000} />
        </Form.Item>
      </Form>
    </Modal>
  );
}
